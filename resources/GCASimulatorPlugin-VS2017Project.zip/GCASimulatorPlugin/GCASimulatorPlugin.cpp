/*
 * GCASimulatorPlugin.c
 * 
 * This plugin provides the GCA Simulator with plot information about all aircrafts in the
 * simulation.
 * 
 */

#if APL
#if defined(__MACH__)
#include <Carbon/Carbon.h>
#endif
#endif

#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <winsock2.h>

#pragma comment(lib,"ws2_32.lib") //Winsock Library

#include "XPLMProcessing.h"
#include "XPLMGraphics.h"
#include "XPLMDataAccess.h"
#include "XPLMUtilities.h"

#define RECBUFLEN 1024	//Max length of receive buffer
#define SENDBUFLEN 4096	//Max length of send buffer
#define TMPBUFLEN 128	
#define LISTENPORT 5005	//The port on which to listen for incoming data
#define SENDTOPORT 5006	//The port to which we will send our answer

/* File to write data to. */
static FILE *	gOutputFile;

/* Data refs we will record. */
static XPLMDataRef		gPlaneLat;
static XPLMDataRef		gPlaneLon;
static XPLMDataRef		gPlaneEl;

XPLMDataRef planeLocalCoords[20 * 3];


#if APL && __MACH__
static int ConvertPath(const char * inPath, char * outPath, int outPathMaxLen);
#endif


static float	MyFlightLoopCallback(
                                   float                inElapsedSinceLastCall,    
                                   float                inElapsedTimeSinceLastFlightLoop,    
                                   int                  inCounter,    
                                   void *               inRefcon);    

SOCKET s;
struct sockaddr_in server, si_other;
int slen = sizeof(si_other);
int recv_len;
char recbuf[RECBUFLEN];
char sendbuf[SENDBUFLEN];
WSADATA wsa;

PLUGIN_API int XPluginStart(
						char *		outName,
						char *		outSig,
						char *		outDesc)
{
	char	outputPath[255];
	#if APL && __MACH__
	char outputPath2[255];
	int Result = 0;
	#endif
		
	strcpy(outName, "GCASimulatorPlugin");
	strcpy(outSig, "Oscar Franz�n");
	strcpy(outDesc, "A plugin that sends plot information to the GCA Simulator.");

	/* Open a file to write to.  We locate the X-System directory 
	 * and then concatenate our file name.  This makes us save in
	 * the X-System directory.  Open the file. */
	XPLMGetSystemPath(outputPath);
	strcat(outputPath, "GCASimulatorPluginLog.txt");

	#if APL && __MACH__
	Result = ConvertPath(outputPath, outputPath2, sizeof(outputPath));
	if (Result == 0)
		strcpy(outputPath, outputPath2);
	else
		XPLMDebugString("GCASimulatorPlugin - Unable to convert path\n");
	#endif
	
	gOutputFile = fopen(outputPath, "w");

	/* Find the data refs we want to record. */
	gPlaneLat = XPLMFindDataRef("sim/flightmodel/position/latitude");
	gPlaneLon = XPLMFindDataRef("sim/flightmodel/position/longitude");
	gPlaneEl = XPLMFindDataRef("sim/flightmodel/position/elevation");

	planeLocalCoords[0 * 3 + 0] = XPLMFindDataRef("sim/flightmodel/position/local_x");
	planeLocalCoords[0 * 3 + 1] = XPLMFindDataRef("sim/flightmodel/position/local_y");
	planeLocalCoords[0 * 3 + 2] = XPLMFindDataRef("sim/flightmodel/position/local_z");

	planeLocalCoords[1 * 3 + 0] = XPLMFindDataRef("sim/multiplayer/position/plane1_x");
	planeLocalCoords[1 * 3 + 1] = XPLMFindDataRef("sim/multiplayer/position/plane1_y");
	planeLocalCoords[1 * 3 + 2] = XPLMFindDataRef("sim/multiplayer/position/plane1_z");

	planeLocalCoords[2 * 3 + 0] = XPLMFindDataRef("sim/multiplayer/position/plane2_x");
	planeLocalCoords[2 * 3 + 1] = XPLMFindDataRef("sim/multiplayer/position/plane2_y");
	planeLocalCoords[2 * 3 + 2] = XPLMFindDataRef("sim/multiplayer/position/plane2_z");

	planeLocalCoords[3 * 3 + 0] = XPLMFindDataRef("sim/multiplayer/position/plane3_x");
	planeLocalCoords[3 * 3 + 1] = XPLMFindDataRef("sim/multiplayer/position/plane3_y");
	planeLocalCoords[3 * 3 + 2] = XPLMFindDataRef("sim/multiplayer/position/plane3_z");

	planeLocalCoords[4 * 3 + 0] = XPLMFindDataRef("sim/multiplayer/position/plane4_x");
	planeLocalCoords[4 * 3 + 1] = XPLMFindDataRef("sim/multiplayer/position/plane4_y");
	planeLocalCoords[4 * 3 + 2] = XPLMFindDataRef("sim/multiplayer/position/plane4_z");

	planeLocalCoords[5 * 3 + 0] = XPLMFindDataRef("sim/multiplayer/position/plane5_x");
	planeLocalCoords[5 * 3 + 1] = XPLMFindDataRef("sim/multiplayer/position/plane5_y");
	planeLocalCoords[5 * 3 + 2] = XPLMFindDataRef("sim/multiplayer/position/plane5_z");

	planeLocalCoords[6 * 3 + 0] = XPLMFindDataRef("sim/multiplayer/position/plane6_x");
	planeLocalCoords[6 * 3 + 1] = XPLMFindDataRef("sim/multiplayer/position/plane6_y");
	planeLocalCoords[6 * 3 + 2] = XPLMFindDataRef("sim/multiplayer/position/plane6_z");

	planeLocalCoords[7 * 3 + 0] = XPLMFindDataRef("sim/multiplayer/position/plane7_x");
	planeLocalCoords[7 * 3 + 1] = XPLMFindDataRef("sim/multiplayer/position/plane7_y");
	planeLocalCoords[7 * 3 + 2] = XPLMFindDataRef("sim/multiplayer/position/plane7_z");

	planeLocalCoords[8 * 3 + 0] = XPLMFindDataRef("sim/multiplayer/position/plane8_x");
	planeLocalCoords[8 * 3 + 1] = XPLMFindDataRef("sim/multiplayer/position/plane8_y");
	planeLocalCoords[8 * 3 + 2] = XPLMFindDataRef("sim/multiplayer/position/plane8_z");

	planeLocalCoords[9 * 3 + 0] = XPLMFindDataRef("sim/multiplayer/position/plane9_x");
	planeLocalCoords[9 * 3 + 1] = XPLMFindDataRef("sim/multiplayer/position/plane9_y");
	planeLocalCoords[9 * 3 + 2] = XPLMFindDataRef("sim/multiplayer/position/plane9_z");

	planeLocalCoords[10 * 3 + 0] = XPLMFindDataRef("sim/multiplayer/position/plane10_x");
	planeLocalCoords[10 * 3 + 1] = XPLMFindDataRef("sim/multiplayer/position/plane10_y");
	planeLocalCoords[10 * 3 + 2] = XPLMFindDataRef("sim/multiplayer/position/plane10_z");

	planeLocalCoords[11 * 3 + 0] = XPLMFindDataRef("sim/multiplayer/position/plane11_x");
	planeLocalCoords[11 * 3 + 1] = XPLMFindDataRef("sim/multiplayer/position/plane11_y");
	planeLocalCoords[11 * 3 + 2] = XPLMFindDataRef("sim/multiplayer/position/plane11_z");

	planeLocalCoords[12 * 3 + 0] = XPLMFindDataRef("sim/multiplayer/position/plane12_x");
	planeLocalCoords[12 * 3 + 1] = XPLMFindDataRef("sim/multiplayer/position/plane12_y");
	planeLocalCoords[12 * 3 + 2] = XPLMFindDataRef("sim/multiplayer/position/plane12_z");

	planeLocalCoords[13 * 3 + 0] = XPLMFindDataRef("sim/multiplayer/position/plane13_x");
	planeLocalCoords[13 * 3 + 1] = XPLMFindDataRef("sim/multiplayer/position/plane13_y");
	planeLocalCoords[13 * 3 + 2] = XPLMFindDataRef("sim/multiplayer/position/plane13_z");

	planeLocalCoords[14 * 3 + 0] = XPLMFindDataRef("sim/multiplayer/position/plane14_x");
	planeLocalCoords[14 * 3 + 1] = XPLMFindDataRef("sim/multiplayer/position/plane14_y");
	planeLocalCoords[14 * 3 + 2] = XPLMFindDataRef("sim/multiplayer/position/plane14_z");

	planeLocalCoords[15 * 3 + 0] = XPLMFindDataRef("sim/multiplayer/position/plane15_x");
	planeLocalCoords[15 * 3 + 1] = XPLMFindDataRef("sim/multiplayer/position/plane15_y");
	planeLocalCoords[15 * 3 + 2] = XPLMFindDataRef("sim/multiplayer/position/plane15_z");

	planeLocalCoords[16 * 3 + 0] = XPLMFindDataRef("sim/multiplayer/position/plane16_x");
	planeLocalCoords[16 * 3 + 1] = XPLMFindDataRef("sim/multiplayer/position/plane16_y");
	planeLocalCoords[16 * 3 + 2] = XPLMFindDataRef("sim/multiplayer/position/plane16_z");

	planeLocalCoords[17 * 3 + 0] = XPLMFindDataRef("sim/multiplayer/position/plane17_x");
	planeLocalCoords[17 * 3 + 1] = XPLMFindDataRef("sim/multiplayer/position/plane17_y");
	planeLocalCoords[17 * 3 + 2] = XPLMFindDataRef("sim/multiplayer/position/plane17_z");

	planeLocalCoords[18 * 3 + 0] = XPLMFindDataRef("sim/multiplayer/position/plane18_x");
	planeLocalCoords[18 * 3 + 1] = XPLMFindDataRef("sim/multiplayer/position/plane18_y");
	planeLocalCoords[18 * 3 + 2] = XPLMFindDataRef("sim/multiplayer/position/plane18_z");

	planeLocalCoords[19 * 3 + 0] = XPLMFindDataRef("sim/multiplayer/position/plane19_x");
	planeLocalCoords[19 * 3 + 1] = XPLMFindDataRef("sim/multiplayer/position/plane19_y");
	planeLocalCoords[19 * 3 + 2] = XPLMFindDataRef("sim/multiplayer/position/plane19_z");



	/* Register our callback for once every tenth second.  Positive intervals
	 * are in seconds, negative are the negative of sim frames.  Zero
	 * registers but does not schedule a callback for time. */
	XPLMRegisterFlightLoopCallback(		
			MyFlightLoopCallback,	/* Callback */
			0.1,					/* Interval */
			NULL);					/* refcon not used. */
	
	

	//Initialise winsock
	//printf("\nInitialising Winsock...");
	fprintf(gOutputFile, "\nInitialising Winsock...");
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
	{
		fprintf(gOutputFile, "Failed. Error Code : %d", WSAGetLastError());
		//printf("Failed. Error Code : %d", WSAGetLastError());
		exit(EXIT_FAILURE);
	}
	fprintf(gOutputFile, "Initialised.\n");
	//printf("Initialised.\n");

	//Create a socket
	if ((s = socket(AF_INET, SOCK_DGRAM, 0)) == INVALID_SOCKET)
	{
		fprintf(gOutputFile, "Could not create socket : %d", WSAGetLastError());
		//printf("Could not create socket : %d", WSAGetLastError());
	}
	fprintf(gOutputFile, "Socket created.\n");
	//printf("Socket created.\n");

	//Prepare the sockaddr_in structure
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_port = htons(LISTENPORT);

	u_long nonblocking = 1;

	/* Set the socket to nonblocking */
	if (ioctlsocket(s, FIONBIO, &nonblocking) != 0)
	{
		fprintf(gOutputFile, "ioctlsocket() failed");
	}


	//Bind
	if (bind(s, (struct sockaddr *)&server, sizeof(server)) == SOCKET_ERROR)
	{
		fprintf(gOutputFile, "Bind failed with error code : %d", WSAGetLastError());
		//printf("Bind failed with error code : %d", WSAGetLastError());
		exit(EXIT_FAILURE);
	}
	fprintf(gOutputFile, "Bind done.\n");
	

	//clear the buffer by filling null, it might have previously received data
	memset(recbuf, '\0', RECBUFLEN);

	fprintf(gOutputFile, "Waiting for data...\n");

	return 1;
}

PLUGIN_API void	XPluginStop(void)
{
	/* Unregister the callback */
	XPLMUnregisterFlightLoopCallback(MyFlightLoopCallback, NULL);

	closesocket(s);
	WSACleanup();
	
	/* Close the file */
	fclose(gOutputFile);
}

PLUGIN_API void XPluginDisable(void)
{
	/* Flush the file when we are disabled.  This is convenient; you 
	 * can disable the plugin and then look at the output on disk. */
	fflush(gOutputFile);
}

PLUGIN_API int XPluginEnable(void)
{

	return 1;
}

PLUGIN_API void XPluginReceiveMessage(
					XPLMPluginID	inFromWho,
					int				inMessage,
					void *			inParam)
{
}

float	MyFlightLoopCallback(
                                   float                inElapsedSinceLastCall,    
                                   float                inElapsedTimeSinceLastFlightLoop,    
                                   int                  inCounter,    
                                   void *               inRefcon)
{
	
	if ((recv_len = recvfrom(s, recbuf, RECBUFLEN, 0, (struct sockaddr *) &si_other, &slen)) == SOCKET_ERROR)
	{
		int last_error = WSAGetLastError();
		if (last_error != WSAEWOULDBLOCK)
		{
			fprintf(gOutputFile, "recvfrom() failed with error code : %d\n", last_error);
			//exit(EXIT_FAILURE);
		}
	}
	
	else {
	

		float	elapsed = XPLMGetElapsedTime();
		fprintf(gOutputFile, "Time=%f: Received a datagram with length %d from GCA Simulator.\n", elapsed, recv_len);
		recbuf[recv_len] = '\0';

		//clear the sendbuffer by filling null, it might have previous data
		memset(sendbuf, '\0', SENDBUFLEN);

		snprintf(sendbuf, sizeof(sendbuf), "xpl,%.3f,", elapsed);

		const char *recv_strings[36];

		char delimiter[] = ",";

		char *ptr = strtok(recbuf, delimiter);
		int i = 0;
		while (ptr != NULL)
		{
			recv_strings[i] = ptr;
			ptr = strtok(NULL, delimiter);
			i++;
		}

		div_t result;
		result = div(i, 6);
		int nbr_of_runways = result.quot;

		double thr_lat_d = 0;
		double thr_lon_d = 0;
		double thr_el_d = 0;
		double eor_lat_d = 0;
		double eor_lon_d = 0;
		double eor_el_d = 0;

		i = 0;
		char *eptr;
		char tmpbuf[TMPBUFLEN];
		

		for (int j = 0; j < nbr_of_runways; j++)
		{
			thr_lat_d = strtod(recv_strings[i], &eptr);
			thr_lon_d = strtod(recv_strings[i+1], &eptr);
			thr_el_d = strtod(recv_strings[i+2], &eptr);
			eor_lat_d = strtod(recv_strings[i+3], &eptr);
			eor_lon_d = strtod(recv_strings[i+4], &eptr);
			eor_el_d = strtod(recv_strings[i+5], &eptr);

			double thr_local_coord[3];
			XPLMWorldToLocal(thr_lat_d, thr_lon_d, thr_el_d, &thr_local_coord[0], &thr_local_coord[1], &thr_local_coord[2]);

			double eor_local_coord[3];
			XPLMWorldToLocal(eor_lat_d, eor_lon_d, eor_el_d, &eor_local_coord[0], &eor_local_coord[1], &eor_local_coord[2]);

			snprintf(tmpbuf, sizeof(tmpbuf), "%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,", thr_local_coord[0], thr_local_coord[1], thr_local_coord[2], eor_local_coord[0], eor_local_coord[1], eor_local_coord[2]);

			strcat(sendbuf, tmpbuf);

			i = i + 6;
		}

		double lat = XPLMGetDataf(gPlaneLat);
		double lon = XPLMGetDataf(gPlaneLon);
		double el = XPLMGetDataf(gPlaneEl);
		snprintf(tmpbuf, sizeof(tmpbuf), "%f,%f,%.1f,", lat, lon, el);
		strcat(sendbuf, tmpbuf);

		memset(tmpbuf, '\0', TMPBUFLEN);

		double x = XPLMGetDataf(planeLocalCoords[0 * 3 + 0]);
		double y = XPLMGetDataf(planeLocalCoords[0 * 3 + 1]);
		double z = XPLMGetDataf(planeLocalCoords[0 * 3 + 2]);
		snprintf(tmpbuf, sizeof(tmpbuf), "player,%f,%f,%.1f,", x, y, z);
		strcat(sendbuf, tmpbuf);

		memset(tmpbuf, '\0', TMPBUFLEN);

		
		for (i = 1; i < 20; i++)
		{
			x = XPLMGetDataf(planeLocalCoords[i * 3 + 0]);
			y = XPLMGetDataf(planeLocalCoords[i * 3 + 1]);
			z = XPLMGetDataf(planeLocalCoords[i * 3 + 2]);
			if (fabs(x) > 0.00001 && fabs(y) > 0.00001 && fabs(z) > 0.00001)
			{
				snprintf(tmpbuf, sizeof(tmpbuf), "aircraft%d,%.1f,%.1f,%.1f,", i, x, y, z);
				strcat(sendbuf, tmpbuf);
				memset(tmpbuf, '\0', TMPBUFLEN);
			}
		}
		

		sendbuf[strlen(sendbuf) - 1] = '\0';

		//fprintf(gOutputFile, "%s\n", sendbuf);

		si_other.sin_port = htons(SENDTOPORT);	//Change port to answer to

		//now reply the client with the same data
		if (sendto(s, sendbuf, strlen(sendbuf), 0, (struct sockaddr*) &si_other, slen) == SOCKET_ERROR)
		{
			fprintf(gOutputFile, "sendto() failed with error code : %d", WSAGetLastError());
			//exit(EXIT_FAILURE);
		}

		// Now, let's throw away all waiting datagrams, so that the next time around we are guaranteed
		// current information and not datagrams thet were sent us seconds ago.
		while ((recv_len = recvfrom(s, recbuf, RECBUFLEN, 0, (struct sockaddr *) &si_other, &slen)) != SOCKET_ERROR)
		{
			//fprintf(gOutputFile, "Threw away a datagram.\n");
		}
	}

	return 0.1;
}


#if APL && __MACH__
#include <Carbon/Carbon.h>
int ConvertPath(const char * inPath, char * outPath, int outPathMaxLen)
{
	CFStringRef inStr = CFStringCreateWithCString(kCFAllocatorDefault, inPath ,kCFStringEncodingMacRoman);
	if (inStr == NULL)
		return -1;
	CFURLRef url = CFURLCreateWithFileSystemPath(kCFAllocatorDefault, inStr, kCFURLHFSPathStyle,0);
	CFStringRef outStr = CFURLCopyFileSystemPath(url, kCFURLPOSIXPathStyle);
	if (!CFStringGetCString(outStr, outPath, outPathMaxLen, kCFURLPOSIXPathStyle))
		return -1;
	CFRelease(outStr);
	CFRelease(url);
	CFRelease(inStr); 	
	return 0;
}
#endif

